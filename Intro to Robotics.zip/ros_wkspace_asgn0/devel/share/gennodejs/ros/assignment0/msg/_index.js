
"use strict";

let TwoInt = require('./TwoInt.js');

module.exports = {
  TwoInt: TwoInt,
};
