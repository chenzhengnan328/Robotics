#!/usr/bin/python3

import rospy
import random
from assignment0.msg import TwoInt

def talker():
	pub = rospy.Publisher('/numbers', TwoInt, queue_size=10)
	rospy.init_node('generator', anonymous=True)
	rate = rospy.Rate(10)
	
	x=TwoInt()
	while not rospy.is_shutdown():
		x.num1 = random.randint(0,100)
		x.num2 = random.randint(0,100)
		rospy.loginfo(x)
		pub.publish(x)
		rate.sleep()
	

if __name__ == '__main__':
	try:
		talker()
	except rospy.ROSInterruptException:
		pass
