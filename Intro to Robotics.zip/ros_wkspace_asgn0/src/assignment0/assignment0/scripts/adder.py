#!/usr/bin/python3

import rospy
from std_msgs.msg import Int16
from assignment0.msg import TwoInt

n = Int16()
def callback(msg):
	n.data = msg.num1 + msg.num2
	rospy.loginfo(n)
	
def listener():
	rospy.init_node('listener')
	pub = rospy.Publisher('/sum', Int16, queue_size=10)
	rospy.Subscriber("/numbers", TwoInt, callback)
	rate = rospy.Rate(10)
	
	while not rospy.is_shutdown():
		pub.publish(n)
		rate.sleep()

		
if __name__ == '__main__':

	try:
		listener()
	except rospy.ROSInterruptException:
		pass
	
