#!/usr/bin/env python3

import time
import math
import numpy
import rospy
from sensor_msgs.msg import JointState
from geometry_msgs.msg import Transform
from cartesian_control.msg import CartesianCommand
from urdf_parser_py.urdf import URDF
import random
import tf
from threading import Thread, Lock

'''This is a class which will perform both cartesian control and inverse
   kinematics'''
class CCIK(object):
    def __init__(self):
    #Load robot from parameter server
        self.robot = URDF.from_parameter_server()

    #Subscribe to current joint state of the robot
        rospy.Subscriber('/joint_states', JointState, self.get_joint_state)

    #This will load information about the joints of the robot
        self.num_joints = 0
        self.joint_names = []
        self.q_current = []
        self.joint_axes = []
        self.get_joint_info()

    #This is a mutex
        self.mutex = Lock()

    #Subscribers and publishers for for cartesian control
        rospy.Subscriber('/cartesian_command', CartesianCommand, self.get_cartesian_command)
        self.velocity_pub = rospy.Publisher('/joint_velocities', JointState, queue_size=10)
        self.joint_velocity_msg = JointState()

        #Subscribers and publishers for numerical IK
        rospy.Subscriber('/ik_command', Transform, self.get_ik_command)
        self.joint_command_pub = rospy.Publisher('/joint_command', JointState, queue_size=10)
        self.joint_command_msg = JointState()

    '''This is a function which will collect information about the robot which
       has been loaded from the parameter server. It will populate the variables
       self.num_joints (the number of joints), self.joint_names and
       self.joint_axes (the axes around which the joints rotate)'''
    def get_joint_info(self):
        link = self.robot.get_root()
        while True:
            if link not in self.robot.child_map: break
            (joint_name, next_link) = self.robot.child_map[link][0]
            current_joint = self.robot.joint_map[joint_name]
            if current_joint.type != 'fixed':
                self.num_joints = self.num_joints + 1
                self.joint_names.append(current_joint.name)
                self.joint_axes.append(current_joint.axis)
            link = next_link

    '''This is the callback which will be executed when the cartesian control
       recieves a new command. The command will contain information about the
       secondary objective and the target q0. At the end of this callback, 
       you should publish to the /joint_velocities topic.'''
    def get_cartesian_command(self, command):
        self.mutex.acquire()
        #--------------------------------------------------------------------------
        #FILL IN YOUR PART OF THE CODE FOR CARTESIAN CONTROL HERE
        
        #  From Command Creat matrix which could calculate Transmation matrix
        
        # print('The command.x_target include these informations \n',command.x_target)
        
        def scale(ve_trans,ve_rot):
            if numpy.linalg.norm(ve_trans) != 0 and numpy.linalg.norm(ve_rot) != 0:
                t_norm = numpy.linalg.norm(ve_trans)
                r_norm = numpy.linalg.norm(ve_rot)
                if t_norm >0.1:
                    ve_trans = 0.1*ve_trans/t_norm
                if r_norm > 1: # 1 rad/s:
                    ve_rot = 1*ve_rot/r_norm
            if numpy.linalg.norm(ve_trans) == 0:
                print('No Valid Translation Norm')
            if numpy.linalg.norm(ve_rot) == 0:
                print('No Valid Rotation Norm')
            if numpy.linalg.norm(ve_trans) == 0 and numpy.linalg.norm(ve_rot) == 0:
                print('No Valid Translation and Rotation Norm')
            return ve_trans, ve_rot
        
        
        command_trans = command.x_target.translation
        command_rot = command.x_target.rotation
        trans_x = command.x_target.translation.x
        trans_y = command.x_target.translation.y
        trans_z = command.x_target.translation.z
        
        rot_x = command.x_target.rotation.x
        rot_y = command.x_target.rotation.y
        rot_z = command.x_target.rotation.z
        rot_w = command.x_target.rotation.w
        
        b_trans_eed = tf.transformations.translation_matrix((trans_x,trans_y,trans_z))
        b_rot_eed = tf.transformations.quaternion_matrix((rot_x,rot_y,rot_z,rot_w))
        
        
        # From Base to the ee_desire (From Command.x_target)
        b_T_eed = numpy.dot(b_trans_eed,b_rot_eed)
        
        # Forward Kinematics of joint T and base to ee T
        joint_transforms, b_T_ee = self.forward_kinematics(self.q_current)
        b_T_j = joint_transforms
        b_T_eec = b_T_ee
        
        # From ee_current to the base
        eec_T_b = numpy.linalg.inv(b_T_eec)
        
        # Calculate x_desire (From ee_current to ee_desire in ee frame)
        eec_T_eed = numpy.dot(eec_T_b,b_T_eed)
        trans_dx = tf.transformations.translation_from_matrix(eec_T_eed)
        trans_dx = trans_dx[0:3]
        
        # Rotation of matrix calculate
        angle, axis = self.rotation_from_matrix(eec_T_eed)
        rot_dx = numpy.dot(angle,axis)
        x_d = numpy.append(trans_dx,rot_dx)
        
        # Scale the velocity (translation and rotation)
        p1 = 1.3  # First gain for Cartesian Control
        p2 = 3    # Second gain for secondary objective
        
        v_trans = p1*trans_dx
        v_rot = p1*rot_dx
        v_trans,v_rot = scale(v_trans,v_rot)
        
        
        # The final velocity of ee
        v_ee = numpy.append(v_trans,v_rot)
        
        # Jacobian
        J = self.get_jacobian(b_T_eec,b_T_j)
        J_s = numpy.linalg.pinv(J,rcond=0.01) # rcond = smallest/largest singular value
        
        # qdot = Js*vee
        q_d = numpy.dot(J_s,v_ee)
        
        # Secondary Objective
        if command.secondary_objective == True:
            # print('The Second objective will require q0 = \n',command.q0_target)
        
            q_sec = numpy.zeros(self.num_joints)
            r0 = command.q0_target
            q0 = self.q_current[0]
            q_sec[0] = p2*(r0-q0)
            I = numpy.identity(self.num_joints)
            J_e = numpy.linalg.pinv(J) # Exact pseudo-inverse
            JJ = numpy.dot(J_e,J)
            q_null = numpy.dot(I-JJ,q_sec)
            q_d = q_d + q_null
        
        # Scale q_d
        
        for i in range(len(q_d)):
            if q_d[i] > 0 and q_d[i] > 1:
                q_d[i] = 1
                print('Positive desired joint velocity been scaled')
            if q_d[i] < 0 and q_d[i] < -1:
                q_d[i] = -1
                print('Negative desired joint velocity been scaled')
        
        self.joint_velocity_msg.name = self.joint_names
        self.joint_velocity_msg.velocity = q_d
        self.velocity_pub.publish(self.joint_velocity_msg)
        
        

        #--------------------------------------------------------------------------
        self.mutex.release()

    '''This is a function which will assemble the jacobian of the robot using the
       current joint transforms and the transform from the base to the end
       effector (b_T_ee). Both the cartesian control callback and the
       inverse kinematics callback will make use of this function.
       Usage: J = self.get_jacobian(b_T_ee, joint_transforms)'''
    def get_jacobian(self, b_T_ee, joint_transforms):
        J = numpy.zeros((6,self.num_joints))
        #--------------------------------------------------------------------------
        #FILL IN YOUR PART OF THE CODE FOR ASSEMBLING THE CURRENT JACOBIAN HERE
        def checkaxis(vector,axis):
            if axis[0] == 0 and axis[1] == 0 and axis[2] == 0:
                print('No Valid Rotation Axes')
            else:
                n = 0
                while n < len(axis):
                    if axis[n] != 0.0:
                        Vj = vector[:,n]*axis[n]
                    n += 1
            return Vj
        
        for i in range(self.num_joints):
            
            # print('Joint Transforms [i] is \n',joint_transforms[i])

            # Joint Transform b_T_j from Base to the joint(i)
            b_T_j = joint_transforms[i]
            j_T_b = tf.transformations.inverse_matrix(b_T_j)
            
            # From joint to ee
            j_T_ee = numpy.dot(j_T_b,b_T_ee)
            
            # From ee to the joint
            ee_T_j = tf.transformations.inverse_matrix(j_T_ee)
            
            # ee_R_j: IR3*3 ee_trans_j: IR3
            # Rotation ee to joint
            ee_R_j = ee_T_j[0:3,0:3]
            
            
            
            # Translation joint to ee
            trans_mid = tf.transformations.translation_from_matrix(j_T_ee)
            j_trans_ee = trans_mid[0:3]
            
            # Funtion S
            x,y,z = j_trans_ee[0],j_trans_ee[1],j_trans_ee[2]
            s = [[0,-z,y],[z,0,-x],[-y,x,0]]
            
            # Matrix Vj
            s_R_T = numpy.dot(-ee_R_j,s)
            
            # The second colum (Top:ee_R_j, Botom:s_RT) of V matrix
            Vj_sc = numpy.append(s_R_T,ee_R_j,axis=0)
            
            # If the rotation axis is [x,y,z]
            axis = self.joint_axes[i]
            axis = axis[0:3]

            Vj = checkaxis(Vj_sc,axis)
            
            J[:,i] = Vj
            
            # print('Rotation Axis of joint = ',axis)
            # print('trans_mid = ',trans_mid)
            # print('s = ',s)
            
        
        
        #--------------------------------------------------------------------------
        return J

    '''This is the callback which will be executed when the inverse kinematics
       recieve a new command. The command will contain information about desired
       end effector pose relative to the root of your robot. At the end of this
       callback, you should publish to the /joint_command topic. This should not
       search for a solution indefinitely - there should be a time limit. When
       searching for two matrices which are the same, we expect numerical
       precision of 10e-3.'''
    def get_ik_command(self, command):
        self.mutex.acquire()
        #--------------------------------------------------------------------------
        #FILL IN YOUR PART OF THE CODE FOR INVERSE KINEMATICS HERE
        	
        trans_x = command.translation.x
        trans_y = command.translation.y
        trans_z = command.translation.z  
        rot_x = command.rotation.x
        rot_y = command.rotation.y
        rot_z = command.rotation.z
        rot_w = command.rotation.w
        
        b_trans_eed = tf.transformations.translation_matrix((trans_x,trans_y,trans_z))
        b_rot_eed = tf.transformations.quaternion_matrix((rot_x,rot_y,rot_z,rot_w))
        b_T_eed = numpy.dot(b_trans_eed,b_rot_eed)

        
        for attemp in range(3):
        
            qc = numpy.random.rand(self.num_joints)*2*math.pi
            qc = numpy.transpose(qc)
            t_start = time.time()
            
            while True:
                joint_transforms,b_T_ee = self.forward_kinematics(qc)
                b_T_j = joint_transforms
                b_T_eec = b_T_ee
                eec_T_b = numpy.linalg.inv(b_T_eec)
                eec_T_eed = numpy.dot(eec_T_b,b_T_eed)
                
                angle, axis = self.rotation_from_matrix(eec_T_eed)
                dx_rot = numpy.dot(angle,axis)
                dx_trans = tf.transformations.translation_from_matrix(eec_T_eed)[0:3]
                
                dx = numpy.append(dx_trans,dx_rot)
                
                J = self.get_jacobian(b_T_ee,joint_transforms)
                J_e = numpy.linalg.pinv(J)
                dq = numpy.dot(J_e,dx)
                
                qc = qc + dq
                 
                dx_max = max(dx)
                dx_min = min(dx)
                
                if dx_max > 0 and dx_max < 0.01 and dx_min < 0 and dx_min > -0.01:
                    attemp = 4
                    break
                
                t_now = time.time()
                t_use = t_now - t_start
                
                if t_use > 10:
                    print('IK took too long time to find solution')
                    break
                    
        if attemp == 4:
            print('IK works')
        if attemp == 3:
            print('IK did not find any solution')
                    
        print('The joint_command_msg include these info',self.joint_command_msg)
        self.joint_command_msg.name = self.joint_names
        self.joint_command_msg.position = qc
        self.joint_command_pub.publish(self.joint_command_msg)
        
               


        #--------------------------------------------------------------------------
        self.mutex.release()

    '''This function will return the angle-axis representation of the rotation
       contained in the input matrix. Use like this: 
       angle, axis = rotation_from_matrix(R)'''
    def rotation_from_matrix(self, matrix):
        R = numpy.array(matrix, dtype=numpy.float64, copy=False)
        R33 = R[:3, :3]
        # axis: unit eigenvector of R33 corresponding to eigenvalue of 1
        l, W = numpy.linalg.eig(R33.T)
        i = numpy.where(abs(numpy.real(l) - 1.0) < 1e-8)[0]
        if not len(i):
            raise ValueError("no unit eigenvector corresponding to eigenvalue 1")
        axis = numpy.real(W[:, i[-1]]).squeeze()
        # point: unit eigenvector of R33 corresponding to eigenvalue of 1
        l, Q = numpy.linalg.eig(R)
        i = numpy.where(abs(numpy.real(l) - 1.0) < 1e-8)[0]
        if not len(i):
            raise ValueError("no unit eigenvector corresponding to eigenvalue 1")
        # rotation angle depending on axis
        cosa = (numpy.trace(R33) - 1.0) / 2.0
        if abs(axis[2]) > 1e-8:
            sina = (R[1, 0] + (cosa-1.0)*axis[0]*axis[1]) / axis[2]
        elif abs(axis[1]) > 1e-8:
            sina = (R[0, 2] + (cosa-1.0)*axis[0]*axis[2]) / axis[1]
        else:
            sina = (R[2, 1] + (cosa-1.0)*axis[1]*axis[2]) / axis[0]
        angle = math.atan2(sina, cosa)
        return angle, axis

    '''This is the function which will perform forward kinematics for your 
       cartesian control and inverse kinematics functions. It takes as input
       joint values for the robot and will return an array of 4x4 transforms
       from the base to each joint of the robot, as well as the transform from
       the base to the end effector.
       Usage: joint_transforms, b_T_ee = self.forward_kinematics(joint_values)'''
    def forward_kinematics(self, joint_values):
        joint_transforms = []

        link = self.robot.get_root()
        T = tf.transformations.identity_matrix()

        while True:
            if link not in self.robot.child_map:
                break

            (joint_name, next_link) = self.robot.child_map[link][0]
            joint = self.robot.joint_map[joint_name]

            T_l = numpy.dot(tf.transformations.translation_matrix(joint.origin.xyz), tf.transformations.euler_matrix(joint.origin.rpy[0], joint.origin.rpy[1], joint.origin.rpy[2]))
            T = numpy.dot(T, T_l)

            if joint.type != "fixed":
                joint_transforms.append(T)
                q_index = self.joint_names.index(joint_name)
                T_j = tf.transformations.rotation_matrix(joint_values[q_index], numpy.asarray(joint.axis))
                T = numpy.dot(T, T_j)

            link = next_link
        return joint_transforms, T #where T = b_T_ee

    '''This is the callback which will recieve and store the current robot
       joint states.'''
    def get_joint_state(self, msg):
        self.mutex.acquire()
        self.q_current = []
        for name in self.joint_names:
            self.q_current.append(msg.position[msg.name.index(name)])
        self.mutex.release()


if __name__ == '__main__':
    rospy.init_node('cartesian_control_and_IK', anonymous=True)
    CCIK()
    rospy.spin()
