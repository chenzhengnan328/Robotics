#!/usr/bin/python3

import rospy
import numpy as np
import tf
import tf2_ros
import geometry_msgs.msg


def publish_transforms():
	# From base_frame to object_frame
	T1_rot = tf.transformations.euler_matrix(0.64, 0.64, 0.0)
	T1_trans = tf.transformations.translation_matrix((1.5, 0.8, 0.0))
	T1 = np.dot(T1_rot,T1_trans)
	
	t1 = geometry_msgs.msg.TransformStamped()
	t1.header.stamp = rospy.Time.now()
	t1.header.frame_id = "base_frame"
	t1.child_frame_id = "object_frame"
	q1 = tf.transformations.quaternion_from_matrix(T1)
	t1.transform.rotation.x = q1[0]
	t1.transform.rotation.y = q1[1]
	t1.transform.rotation.z = q1[2]
	t1.transform.rotation.w = q1[3]
	tr1 = tf.transformations.translation_from_matrix(T1)
	t1.transform.translation.x = tr1[0]
	t1.transform.translation.y = tr1[1]
	t1.transform.translation.z = tr1[2]
	br.sendTransform(t1)
    	
    	# From base_frame to robot_frame
	T2_rot = tf.transformations.euler_matrix(0.0, 1.5, 0.0)
	T2_trans = tf.transformations.translation_matrix((0.0, 0.0, -2.0))
	T2 = np.dot(T2_rot,T2_trans)
	
	t2 = geometry_msgs.msg.TransformStamped()
	t2.header.stamp = rospy.Time.now()
	t2.header.frame_id = "base_frame"
	t2.child_frame_id = "robot_frame"
	q2 = tf.transformations.quaternion_from_matrix(T2)
	t2.transform.rotation.x = q2[0]
	t2.transform.rotation.y = q2[1]
	t2.transform.rotation.z = q2[2]
	t2.transform.rotation.w = q2[3]
	tr2 = tf.transformations.translation_from_matrix(T2)
	t2.transform.translation.x = tr2[0]
	t2.transform.translation.y = tr2[1]
	t2.transform.translation.z = tr2[2]
	br.sendTransform(t2)
	

	# From robot_frame to camera_frame
	T3_trans = tf.transformations.translation_matrix((0.3, 0.0, 0.3))
	T_b_o = T1
	T_b_r = T2
	T_r_c = T3_trans
	T_c_r = tf.transformations.inverse_matrix(T_r_c)
	T_r_b = tf.transformations.inverse_matrix(T_b_r)
	
	# cTo = cTr rTb bTo
	# cpo = cTo opo
	
	T_c_o = np.linalg.multi_dot([T_c_r,T_r_b,T_b_o])
	p_o_o = np.array([0,0,0,1])
	P_c_o = np.dot(T_c_o,p_o_o)[0:3]
	camera_x = np.array([1,0,0])
	rotaxis = np.cross(camera_x,P_c_o)
	costheta = np.dot(camera_x,P_c_o)/np.linalg.norm(P_c_o)
	theta = np.arccos(costheta)
	

	t3 = geometry_msgs.msg.TransformStamped()
	t3.header.stamp = rospy.Time.now()
	t3.header.frame_id = "robot_frame"
	t3.child_frame_id = "camera_frame"
	q3 = tf.transformations.quaternion_about_axis(theta,(rotaxis))
	t3.transform.translation.x = 0.3
	t3.transform.translation.y = 0.0
	t3.transform.translation.z = 0.3
	t3.transform.rotation.x = q3[0]
	t3.transform.rotation.y = q3[1]
	t3.transform.rotation.z = q3[2]
	t3.transform.rotation.w = q3[3]
	br.sendTransform(t3)
	
	# print(T1_trans)
	trans_mid = tf.transformations.translation_from_matrix(T1)
	j_trans_ee = trans_mid[0:3]
	x = j_trans_ee[1]
	print(x)
	#print('j',j_trans_ee)


if __name__ == '__main__':
    rospy.init_node('solution')

    br = tf2_ros.TransformBroadcaster()
    rospy.sleep(0.1)

    while not rospy.is_shutdown():
        publish_transforms()
        rospy.sleep(0.1)



