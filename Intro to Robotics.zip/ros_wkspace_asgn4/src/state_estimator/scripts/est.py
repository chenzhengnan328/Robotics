#!/usr/bin/env python3

# Columbia Engineering
# MECS 4602 - Fall 2018

import math
import numpy
import time

import rospy

from state_estimator.msg import RobotPose
from state_estimator.msg import SensorData

class Estimator(object):
    def __init__(self):

        # Publisher to publish state estimate
        self.pub_est = rospy.Publisher("/robot_pose_estimate", RobotPose, queue_size=1)

        # Initial estimates for the state and the covariance matrix
        self.x = numpy.zeros((3,1))
        self.P = numpy.zeros((3,3))

        # Covariance matrix for process (model) noise
        self.V = numpy.zeros((3,3))
        self.V[0,0] = 0.0025
        self.V[1,1] = 0.0025
        self.V[2,2] = 0.005

        self.step_size = 0.01

        # Subscribe to command input and sensory output of robot
        rospy.Subscriber("/sensor_data", SensorData, self.sensor_callback)
        
    # This function gets called every time the robot publishes its control 
    # input and sensory output. You must make use of what you know about 
    # extended Kalman filters to come up with an estimate of the current
    # state of the robot and covariance matrix.
    # The SensorData message contains fields 'vel_trans' and 'vel_ang' for
    # the commanded translational and rotational velocity respectively. 
    # Furthermore, it contains a list 'readings' of the landmarks the
    # robot can currently observe
    
    def calrange(self,x1,x2,y1,y2):
        distance = numpy.sqrt((x1-x2)**2+(y1-y2)**2)
        return distance
    
    def calbearing(self,x1,x2,y1,y2,thetar):
        bearing = math.atan2(y2-y1,x2-x1) - thetar
        return bearing
    
    def testpoints(self,sens):
        result = False
        points = len(sens.readings)
        if points != 0:
            result = True
        return points,result
    
    def estimate(self, sens):
        ####
        #### ----- YOUR CODE GOES HERE ----- ####
        
        # Parameter Define
        x = self.x[0]
        y = self.x[1]
        theta = self.x[2]
        v = sens.vel_trans
        w = sens.vel_ang
        T = 0.01
        
        #### Kinematic Part
        # x_^(k+1)
        x_hkp1 = numpy.zeros((3,1))
        xaxis_hkp1 = x + T * v * numpy.cos(theta)
        yaxis_hkp1 = y + T * v * numpy.sin(theta)
        theta_hkp1 = theta + T * w
        x_hkp1[0] = xaxis_hkp1
        x_hkp1[1] = yaxis_hkp1
        x_hkp1[2] = theta_hkp1
        
        f = x_hkp1
        
        u = numpy.zeros((2,1))
        u[0] = v
        u[1] = w
        
        F = numpy.identity(3)
        F[0,2] = -T * v * numpy.sin(theta)
        F[1,2] = T * v * numpy.cos(theta)
        
        G = numpy.zeros((3,2))
        G[0,0] = T * numpy.cos(theta)
        G[0,1] = T * numpy.sin(theta)
        G[2,1] = T
        
        V = self.V
        P = self.P
        F_T = numpy.transpose(F)
        P_hkp1 = numpy.linalg.multi_dot([F, P, F_T]) + V
        
        # Set x(k+1) to kinematic x^(k+1) if no sensor data
        x_kp1 = x_hkp1
        P_kp1 = P_hkp1
        
        ## Sensor Part
        points,result = self.testpoints(sens)
        if result == True:
            #### Initialize parameter
            row = 2 * points
            # sensor Read y(k+1)
            y_kp1 = numpy.zeros((row,1))
            
            # Calculate h(x^(k+1))
            h = numpy.zeros((row,1))
            xr = x_hkp1[0]
            yr = x_hkp1[1]
            thetar = x_hkp1[2]
            
            # Calculate H Jacabian
            H = numpy.zeros((row,3))
            
            # Write Sensor Data
            for i in range(points):
                frow = 2*i
                srow = 2*i+1
                
                RANGE = sens.readings[i].range
                BEARING = sens.readings[i].bearing
                y_kp1[frow] = RANGE
                y_kp1[srow] = BEARING
            
                # Calculate h(x^(k+1))
                xl = sens.readings[i].landmark.x
                yl = sens.readings[i].landmark.y
                Range = self.calrange(xr,xl,yr,yl)
                Bearing = math.atan2(yl-yr,xl-xr) - thetar
                h[frow] = Range
                h[srow] = Bearing
                
                # Calculate H Jacobian
                if Range > 0.1:
                    H[frow,0] = (xr-xl)/Range
                    H[srow,0] = (-yr+yl)/Range**2
                    H[frow,1] = (yr-yl)/Range
                    H[srow,1] = (xr-xl)/Range**2
                    H[frow,2] = 0
                    H[srow,2] = -1
                else:
                    for i in range(2):
                        H[frow,i] = 0
                        H[srow,i] = 0

        if result == True:
            row = 2 * points
            
            # Calculate Variance Matrix
            W = numpy.identity(row)   
            for i in range(points):
                # Calculate Variance Matrix W
                W[2*i,2*i] = 0.1
                W[2*i+1,2*i+1] = 0.05
                
            # Calculate nu = y(k+1) - h(x^(k+1))
            nu = y_kp1 - h
            
            # Scale nu
            for each in nu:
                mag = abs(each)
                if mag > numpy.pi:
                    if each < -numpy.pi:
                        each += 2*numpy.pi
                    if each > numpy.pi:
                        each -= 2*numpy.pi
                else:
                    each = each
            
            #### kinematic and Sensor
            H_T = numpy.transpose(H)
            S = numpy.linalg.multi_dot([H, P_hkp1, H_T]) + W
            S_inv = numpy.linalg.inv(S)
            R = numpy.linalg.multi_dot([P_hkp1, H_T, S_inv])
            
            #### Calculate x(k+1)
            x_kp1 = x_hkp1 + numpy.dot(R,nu)
            P_kp1 = P_hkp1 - numpy.linalg.multi_dot([R, H, P_hkp1])
            
        # Update
        self.x = x_kp1
        self.P = P_kp1
        
        #### ----- YOUR CODE GOES HERE ----- ####
    
    def sensor_callback(self,sens):

        # Publish state estimate 
        self.estimate(sens)
        est_msg = RobotPose()
        est_msg.header.stamp = sens.header.stamp
        est_msg.pose.x = self.x[0]
        est_msg.pose.y = self.x[1]
        est_msg.pose.theta = self.x[2]
        self.pub_est.publish(est_msg)

if __name__ == '__main__':
    rospy.init_node('state_estimator', anonymous=True)
    est = Estimator()
    rospy.spin()
